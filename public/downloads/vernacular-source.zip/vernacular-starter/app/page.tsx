import {ProjectExperience} from '@/components/project-experience';
import {SiteFooter} from '@/components/site-footer';
export const metadata={title:"VERNACULAR"};
export default function Home(){return <main className="standalone-site site-vernacular" id="site-top"><ProjectExperience slug="vernacular"/><SiteFooter slug="vernacular"/></main>}
