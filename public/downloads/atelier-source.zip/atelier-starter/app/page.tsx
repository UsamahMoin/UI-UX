import {ProjectExperience} from '@/components/project-experience';
import {SiteFooter} from '@/components/site-footer';
export const metadata={title:"ATELIER"};
export default function Home(){return <main className="standalone-site site-atelier" id="site-top"><ProjectExperience slug="atelier"/><SiteFooter slug="atelier"/></main>}
