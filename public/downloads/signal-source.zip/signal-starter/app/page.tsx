import {ProjectExperience} from '@/components/project-experience';
import {SiteFooter} from '@/components/site-footer';
export const metadata={title:"SIGNAL"};
export default function Home(){return <main className="standalone-site site-signal" id="site-top"><ProjectExperience slug="signal"/><SiteFooter slug="signal"/></main>}
