import {sitePath} from '@/lib/site-path';
import {experiencePath} from '@/lib/experience-path';
import {identities} from '@/lib/project-identities';
export default function About(){const i=identities['civic'];return <main style={{maxWidth:900,margin:'auto',padding:'60px 24px',fontFamily:'sans-serif',lineHeight:1.7}}><a href={sitePath(experiencePath('civic'))}>Open CIVIC</a><h1>CIVIC</h1><h2>{i.name}</h2><p>{i.idea}</p><p>{i.signature}</p><section id="download"><h2>Make it your own</h2><p>This folder contains the editable source. See README.md for setup and customization.</p><a href="https://usamahmoin.github.io/UI-UX/work/civic/">Original case study and source download</a></section></main>}
