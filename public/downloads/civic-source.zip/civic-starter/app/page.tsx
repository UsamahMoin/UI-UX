import {ProjectExperience} from '@/components/project-experience';
import {SiteFooter} from '@/components/site-footer';
export const metadata={title:"CIVIC"};
export default function Home(){return <main className="standalone-site site-civic" id="site-top"><ProjectExperience slug="civic"/><SiteFooter slug="civic"/></main>}
