import {ProjectExperience} from '@/components/project-experience';
import {SiteFooter} from '@/components/site-footer';
export const metadata={title:"MERIDIAN"};
export default function Home(){return <main className="standalone-site site-meridian" id="site-top"><ProjectExperience slug="meridian"/><SiteFooter slug="meridian"/></main>}
