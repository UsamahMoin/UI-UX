import {ProjectExperience} from '@/components/project-experience';
import {SiteFooter} from '@/components/site-footer';
export const metadata={title:"NOVA"};
export default function Home(){return <main className="standalone-site site-nova" id="site-top"><ProjectExperience slug="nova"/><SiteFooter slug="nova"/></main>}
