export {default,metadata} from './work/serein/residence/page';
