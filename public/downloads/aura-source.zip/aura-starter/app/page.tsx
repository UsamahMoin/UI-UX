import {ProjectExperience} from '@/components/project-experience';
import {SiteFooter} from '@/components/site-footer';
export const metadata={title:"AURA"};
export default function Home(){return <main className="standalone-site site-aura" id="site-top"><ProjectExperience slug="aura"/><SiteFooter slug="aura"/></main>}
