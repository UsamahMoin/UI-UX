import {ProjectExperience} from '@/components/project-experience';
import {SiteFooter} from '@/components/site-footer';
export const metadata={title:"FORM"};
export default function Home(){return <main className="standalone-site site-form" id="site-top"><ProjectExperience slug="form"/><SiteFooter slug="form"/></main>}
