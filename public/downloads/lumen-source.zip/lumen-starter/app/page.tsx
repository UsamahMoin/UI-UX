import {ProjectExperience} from '@/components/project-experience';
import {SiteFooter} from '@/components/site-footer';
export const metadata={title:"LUMEN"};
export default function Home(){return <main className="standalone-site site-lumen" id="site-top"><ProjectExperience slug="lumen"/><SiteFooter slug="lumen"/></main>}
