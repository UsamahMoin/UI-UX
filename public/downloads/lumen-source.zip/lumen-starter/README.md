# LUMEN — editable website

A local React / TypeScript starter from Usamah Moin's interface portfolio.

## Run

1. Install Node.js 22.13 or newer.
2. In this folder run `npm install`.
3. Run `npm run dev` and open the localhost URL printed in the terminal.
4. `npm run build` checks and builds the production site; `npm start` serves it.

No Sites account, Cloudflare account, API key, or private deployment configuration is included or required.

## Make changes

- `app/page.tsx`: the project's entry page.
- `components/project-experience.tsx`: the project interface and interactions.
- `components/nova-dashboard.tsx` and `components/signal-dashboard.tsx`: data dashboards.
- `components/brand-mark.tsx`: editable vector marks.
- `app/*.css`: base and project styles; `experience.css` holds the full-page refinements.
- `app/work/lumen/`: internal pages, where this project has them.
- `public/images/`: this project's image assets.
- `lib/`: data calculations and helpers.

Shared components are included so imports remain editable without a private package.
Only this project's pages and images are exposed. Paths work from a localhost origin; set
`NEXT_PUBLIC_BASE_PATH` and adjust the build configuration if deploying below a subdirectory.

## Demo boundaries

This is a fictional portfolio concept. Payments, hotel availability, civic submissions,
commerce, and account connections are demonstrations, not connected services. Local-only
state and reset behavior are labeled in the interface. Add your own backend and credentials
before using it as a real service. Photography includes AI-generated concept images.

## Reuse

You may edit and adapt the original interface code and included concept assets for your own
projects. Third-party dependencies keep their respective licenses. This is provided as-is.
Original design and implementation: Usamah Moin. Do not represent fictional products,
people, places or generated photography as verified real-world offerings.
