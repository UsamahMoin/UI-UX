import {ProjectExperience} from '@/components/project-experience';
import {SiteFooter} from '@/components/site-footer';
export const metadata={title:"FIELD"};
export default function Home(){return <main className="standalone-site site-field" id="site-top"><ProjectExperience slug="field"/><SiteFooter slug="field"/></main>}
