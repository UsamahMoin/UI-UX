import {ProjectExperience} from '@/components/project-experience';
import {SiteFooter} from '@/components/site-footer';
export const metadata={title:"SCRIBBLE"};
export default function Home(){return <main className="standalone-site site-pantry" id="site-top"><ProjectExperience slug="pantry"/><SiteFooter slug="pantry"/></main>}
